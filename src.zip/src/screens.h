#pragma once

void drawCurrentScreen();
