#pragma once

void drawCompassPage();
