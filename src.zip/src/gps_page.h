#pragma once

void drawGPSPage();
