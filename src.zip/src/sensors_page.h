#pragma once

void drawSensorPage();
