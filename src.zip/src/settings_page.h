#pragma once

void drawSettingsPage();
